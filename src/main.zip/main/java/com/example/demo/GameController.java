package com.example.demo;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/api")
public class GameController {
    private Map<String, GameSession> sessions = new HashMap<>();

    @GetMapping("/startSession")
    public String startSession() {
        String code = String.format("%04d", new Random().nextInt(10000));
        sessions.put(code, new GameSession(code));
        System.out.println("Created new session with code: " + code);  // Log session creation for debugging

        // Redirect to the frontend game page at localhost:8000/game/{sessionCode}
        return "redirect:http://localhost:8000/game/" + code;
    }

    // Join an existing game and redirect to frontend game page
    @PostMapping("/joinGame")
    public ResponseEntity<String> joinGame(@RequestBody Map<String, String> body) {
        String code = body.get("code");
        GameSession session = sessions.get(code);

        if (session != null && session.join()) {
            // Redirect to the frontend game page at localhost:8000/game/{sessionCode}
            return ResponseEntity.status(302)  // HTTP 302 Found - redirect
                    .header("Location", "http://localhost:8000/game/" + code)
                    .build();
        } else {
            return ResponseEntity.badRequest().body("Invalid or full session.");
        }
    }

    @PostMapping("/toggle")
    public ResponseEntity<String> toggle(@RequestBody Map<String, String> body) {
        String code = body.get("sessionCode");
        String newState = body.get("newState");

        GameSession session = sessions.get(code);
        if (session != null) {
            session.setState(newState);
            return ResponseEntity.ok("State updated.");
        } else {
            return ResponseEntity.badRequest().body("Session not found.");
        }
    }
}