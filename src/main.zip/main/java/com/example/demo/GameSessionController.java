package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class GameSessionController {

    // This method serves the game page, passing the session code to the frontend
    @GetMapping("/game/{sessionCode}")
    public String getSessionPage(@PathVariable String sessionCode, Model model) {
        model.addAttribute("sessionCode", sessionCode);  // Pass sessionCode to the frontend
        return "game";  // Return the view name (game.html)
    }
}
