// Function to start a new game session
function startSession() {
    fetch('http://localhost:8080/api/startSession')
        .then(response => response.json())
        .then(data => {
            const sessionCode = data.sessionCode;
            document.getElementById("session-code").textContent = sessionCode;
            document.getElementById("session-code-container").style.display = "block";

            // Redirect to the game session page (frontend port 8000)
            window.location.href = `http://localhost:8000/game/${sessionCode}`;
        })
        .catch(error => {
            console.error('Error creating session:', error);
        });
}

// Function to join an existing game session
function joinGame() {
    const sessionCode = document.getElementById("code-input").value;

    fetch('http://localhost:8080/api/joinGame', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ code: sessionCode })
    })
        .then(response => {
            if (response.ok) {
                alert('Successfully joined the game!');
                // Redirect to the game session page (frontend port 8000)
                window.location.href = `http://localhost:8000/game/${sessionCode}`;
            } else {
                alert('Failed to join the game. Please check the session code.');
            }
        })
        .catch(error => {
            console.error('Error joining the game:', error);
        });
}

// Function to toggle the game state (unchanged)
function toggleState() {
    const toggleButton = document.getElementById("toggle-button");
    toggleButton.textContent = toggleButton.textContent === "0" ? "1" : "0";
}
