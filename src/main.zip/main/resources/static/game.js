// Extract session code from the URL
const sessionCode = window.location.pathname.split('/').pop();
document.getElementById("session-info").textContent = `Session Code: ${sessionCode}`;

// Optionally, you can use the session code to fetch and display session data
console.log(`Session Code: ${sessionCode}`);

// Function to toggle button state and communicate with the backend
function toggleState() {
    const toggleButton = document.getElementById("toggle-button");
    const newState = toggleButton.textContent === "0" ? "1" : "0";  // Toggle between 0 and 1
    toggleButton.textContent = newState;

    // Send the state change to the backend
    fetch(`http://localhost:8080/api/toggle`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            sessionCode: sessionCode,
            newState: newState
        })
    })
        .then(response => response.json())
        .then(data => {
            console.log('State updated:', data);
        })
        .catch(error => {
            console.error('Error updating state:', error);
        });
}
